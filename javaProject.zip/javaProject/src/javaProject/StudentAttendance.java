package javaProject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

//first, class representing a student.
class Student {
    private String name;
    private String id; 

    public Student(String id, String name) {
        this.id = id; 
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getId() { 
        return id;
    }
}

//tapos dito sa part na to mina-manage yung student records and attendance.
class AttendanceSystem {
    private ArrayList<Student> students;
    private HashMap<String, Boolean> attendanceRecord; 

    public AttendanceSystem() {
        students = new ArrayList<>();
        attendanceRecord = new HashMap<>();
    }

 // ito yung part na mag add ng student sa system
    public void addStudent(String id, String name) { 
        Student student = new Student(id, name);
        students.add(student);
        attendanceRecord.put(id, false);  // default means absent
    }

 // then dito yung part na magma-mark if present or absent.
    public void markAttendance(String id, boolean isPresent) { 
        if (attendanceRecord.containsKey(id)) {
            attendanceRecord.put(id, isPresent);
            System.out.println("Attendance marked for student ID: " + id);
        } else {
            System.out.println("Student not found.");
        }
    }

// ito yung magdi-display na attendance
    public void displayAttendance() {
        System.out.println("Attendance Record:");
        for (Student student : students) {
            boolean isPresent = attendanceRecord.get(student.getId());
            System.out.println("ID: " + student.getId() + " | Name: " + student.getName() +
                    " | Attendance: " + (isPresent ? "Present" : "Absent"));
        }
    }
}

/// tapos dito na yung main class na magi-interact sa attendance system natin.
public class StudentAttendance {
    public static void main(String[] args) {
        AttendanceSystem attendanceSystem = new AttendanceSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Attendance System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Mark Attendance");
            System.out.println("3. Display Attendance");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    String id = scanner.next(); 
                    scanner.nextLine();  
                    System.out.print("Enter Student Name: ");
                    String name = scanner.nextLine();
                    attendanceSystem.addStudent(id, name);
                    break;

                case 2:
                    System.out.print("Enter Student ID: ");
                    id = scanner.next(); 
                    System.out.print("Is the student present? (true/false): ");
                    boolean isPresent = scanner.nextBoolean();
                    attendanceSystem.markAttendance(id, isPresent);
                    break;

                case 3:
                    attendanceSystem.displayAttendance();
                    break;

                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
